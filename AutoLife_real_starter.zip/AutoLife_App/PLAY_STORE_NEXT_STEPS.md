# Google Play üçün növbəti mərhələ

Bu web app artıq mobil-first hazırlanıb. Android tətbiqinə çevirmək üçün ən rahat yol Capacitor kimi bir wrapper ilə Android layihəsi yaratmaqdır.

Tipik mərhələ:
1. Node.js
2. Capacitor əlavə etmək
3. Android Studio ilə Android layihəsini açmaq
4. Debug cihazında test
5. Release signing
6. `.aab` yaratmaq
7. Google Play Console-da tətbiqi yaratmaq və AAB yükləmək

Bu paketdə hələ imzalanmış `.aab` yoxdur; onu Android build mühitində yaratmaq lazımdır.
