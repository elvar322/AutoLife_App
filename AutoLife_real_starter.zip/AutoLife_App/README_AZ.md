# AutoLife — işlək başlanğıc layihə

Bu paket artıq sadəcə dizayn şəkli deyil. İçində:
- Mobil-first AutoLife interfeysi
- Ana səhifə
- AI bölməsi
- Mənim avtomobilim
- Mağaza
- Servis
- Sifarişlər
- Bildirişlər/xatırlatmalar
- Profil
- Admin panel demo
- LocalStorage ilə avtomobil və xatırlatma məlumatlarının saxlanması
- Node/Express backend
- `/api/health`
- `/api/ai` üçün AI inteqrasiya nöqtəsi
- PWA manifest

## Kompüterdə işə salmaq

Node.js qurulu olduqdan sonra:

```bash
npm install
npm start
```

Sonra brauzerdə:
`http://localhost:3000`

## Render

Bu layihəni Render-də Node Web Service kimi yerləşdirmək olar.

Build command:
`npm install`

Start command:
`npm start`

Portu server özü `process.env.PORT` ilə götürür.

## Növbəti mərhələ

Bu starteri production tətbiqə çevirmək üçün:
1. Real PostgreSQL database
2. İstifadəçi qeydiyyatı/login
3. Real VIN decoder/API
4. Real servis və xəritə məlumatları
5. Real mağaza və ödəniş
6. Real AI provider API
7. Push notifications
8. Android/iOS build
9. Google Play release

Qeyd: `server.js`-də AI endpoint hazırda demo cavab verir; real AI üçün provider API açarı və sorğu kodu əlavə edilməlidir.
