const state = JSON.parse(localStorage.getItem("autolife") || "null") || {
  car:{brand:"BMW", model:"5 Series", year:"2020", plate:"10-AB-010", vin:""},
  reminders:[
    {title:"Mühərrik yağı",date:"2026-10-15",icon:"🛢️"},
    {title:"Təkər yoxlanışı",date:"2026-11-01",icon:"🛞"}
  ],
  notifications:2,
  messages:[{role:"ai",text:"Salam! Mən AutoLife AI köməkçisiyəm. Avtomobilinlə bağlı nə bilmək istəyirsən?"}]
};
function save(){localStorage.setItem("autolife",JSON.stringify(state))}
function navigate(route){
  window.location.hash=route;
  render();
  window.scrollTo(0,0);
}
function current(){return location.hash.replace("#","")||"home"}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function layout(body){
  return `<div class="content">${body}</div>`;
}
function render(){
  const r=current(), app=document.getElementById("app");
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.route===r));
  document.getElementById("badge").style.display=state.notifications?"block":"none";
  const pages={home:home,ai:ai,car:car,shop:shop,profile:profile,notifications:notifications,service:service,orders:orders,admin:admin};
  app.innerHTML=layout((pages[r]||home)());
}
function home(){
  const c=state.car;
  return `<div class="hero">
    <div class="muted">Sizin avtomobiliniz</div><h1>${esc(c.brand)} ${esc(c.model)}</h1>
    <div class="muted">${esc(c.year)} · ${esc(c.plate)}</div>
    <div class="car-art">🚘</div>
    <button class="primary" onclick="navigate('car')">Avtomobilə bax →</button>
  </div>
  <div class="section-title"><h2>Sürətli giriş</h2></div>
  <div class="grid">
    <div class="card" onclick="navigate('ai')"><div class="tile-icon">✦</div><h3>AI Köməkçi</h3><p>Avtomobil problemini təsvir et.</p></div>
    <div class="card" onclick="navigate('service')"><div class="tile-icon">🔧</div><h3>Servis</h3><p>Servis tap və rezervasiya et.</p></div>
    <div class="card" onclick="navigate('shop')"><div class="tile-icon">🛒</div><h3>Mağaza</h3><p>Avtomobil məhsullarına bax.</p></div>
    <div class="card" onclick="navigate('orders')"><div class="tile-icon">📋</div><h3>Sifarişlər</h3><p>Sifariş və ödənişləri gör.</p></div>
  </div>
  <div class="section-title"><h2>Yaxın xatırlatmalar</h2><span class="link" onclick="navigate('notifications')">Hamısı</span></div>
  <div class="list">${state.reminders.slice(0,2).map(x=>`<div class="row"><span class="tile-icon">${x.icon}</span><div class="grow"><strong>${esc(x.title)}</strong><small>${esc(x.date)}</small></div><span class="pill">Planlı</span></div>`).join("")}</div>`;
}
function ai(){
 return `<div class="ai-box"><div class="section-title"><h2>AutoLife AI</h2><span class="pill">LIVE</span></div>
 <div class="messages" id="messages">${state.messages.map(m=>`<div class="msg ${m.role==='user'?'user':'ai'}">${esc(m.text)}</div>`).join("")}</div>
 <div class="composer"><input id="aiInput" placeholder="Məs: Yağı nə vaxt dəyişməliyəm?" onkeydown="if(event.key==='Enter')sendAI()"><button onclick="sendAI()">➤</button></div></div>`;
}
async function sendAI(){
 const el=document.getElementById("aiInput"); const text=el.value.trim(); if(!text)return;
 state.messages.push({role:"user",text}); save(); render(); navigate("ai");
 try{
  const res=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text})});
  const data=await res.json(); state.messages.push({role:"ai",text:data.answer||"Cavab alınmadı."});
 }catch(e){state.messages.push({role:"ai",text:"Serverə qoşulmaq mümkün olmadı. Sonra yenidən yoxla."})}
 save(); render(); navigate("ai");
}
function car(){
 const c=state.car;
 return `<button class="back" onclick="navigate('home')">← Geri</button><div class="hero"><div class="muted">Mənim avtomobilim</div><h1>${esc(c.brand)} ${esc(c.model)}</h1><div class="car-art">🚗</div></div>
 <div class="section-title"><h2>Məlumatlar</h2></div>
 <div class="form">
 <input class="input" id="brand" value="${esc(c.brand)}" placeholder="Marka">
 <input class="input" id="model" value="${esc(c.model)}" placeholder="Model">
 <input class="input" id="year" value="${esc(c.year)}" placeholder="İl">
 <input class="input" id="plate" value="${esc(c.plate)}" placeholder="Dövlət nömrəsi">
 <input class="input" id="vin" value="${esc(c.vin)}" placeholder="VIN">
 <button class="primary" onclick="saveCar()">Yadda saxla</button></div>`;
}
function saveCar(){state.car={brand:brand.value,model:model.value,year:year.value,plate:plate.value,vin:vin.value};save();navigate("car")}
function shop(){
 const products=[["🛢️","Mühərrik yağı","5W-30 sintetik","49.90 ₼"],["🔩","Yağ filtri","Premium filter","12.50 ₼"],["🛞","Təkər","205/55 R16","149 ₼"],["🔋","Akkumulyator","12V","220 ₼"]];
 return `<div class="section-title"><h2>AutoLife Mağaza</h2><span class="pill">4 məhsul</span></div><div class="list">${products.map(p=>`<div class="row product"><div class="pic">${p[0]}</div><div class="grow"><strong>${p[1]}</strong><small>${p[2]}</small><div class="price">${p[3]}</div></div><button class="icon-btn" onclick="alert('Məhsul səbətə əlavə edildi')">＋</button></div>`).join("")}</div>`;
}
function service(){
 const services=[["🔧","AutoLife Service","Yağ, filtr, diaqnostika","4.9 ★"],["⚙️","Pro Auto","Mühərrik və elektrik","4.8 ★"],["🛠️","Garage 24","Ümumi servis","4.7 ★"]];
 return `<div class="section-title"><h2>Servis mərkəzləri</h2></div><div class="list">${services.map(s=>`<div class="row"><span class="tile-icon">${s[0]}</span><div class="grow"><strong>${s[1]}</strong><small>${s[2]}</small></div><span class="pill">${s[3]}</span></div>`).join("")}</div><div class="section-title"><h2>Rezervasiya</h2></div><div class="card"><div class="form"><input class="input" type="date" id="serviceDate"><button class="primary" onclick="alert('Servis rezervasiyası demo olaraq yaradıldı')">Rezervasiya et</button></div></div>`;
}
function orders(){return `<div class="section-title"><h2>Sifarişlər</h2></div><div class="card"><strong>Hələ sifariş yoxdur</strong><p>Mağazadan məhsul seçəndə burada görünəcək.</p></div>`}
function notifications(){
 return `<div class="section-title"><h2>Bildirişlər və xatırlatmalar</h2></div><div class="list">${state.reminders.map((x,i)=>`<div class="row"><span class="tile-icon">${x.icon}</span><div class="grow"><strong>${esc(x.title)}</strong><small>${esc(x.date)}</small></div><button class="icon-btn" onclick="deleteReminder(${i})">×</button></div>`).join("")}</div><div class="section-title"><h2>Yeni xatırlatma</h2></div><div class="form"><input class="input" id="remTitle" placeholder="Məs: Yağ dəyişmə"><input class="input" id="remDate" type="date"><button class="primary" onclick="addReminder()">Əlavə et</button></div>`;
}
function addReminder(){if(!remTitle.value||!remDate.value)return;state.reminders.push({title:remTitle.value,date:remDate.value,icon:"🔔"});save();render()}
function deleteReminder(i){state.reminders.splice(i,1);save();render()}
function profile(){return `<div class="hero"><div class="muted">Profil</div><h1>AutoLife istifadəçisi</h1><p class="muted">Hesab və tətbiq parametrləri</p></div><div class="grid"><div class="card" onclick="navigate('car')"><div class="tile-icon">🚗</div><h3>Avtomobilim</h3><p>Məlumatları idarə et</p></div><div class="card" onclick="navigate('notifications')"><div class="tile-icon">🔔</div><h3>Xatırlatmalar</h3><p>Planlarını idarə et</p></div><div class="card" onclick="navigate('admin')"><div class="tile-icon">⚙️</div><h3>Admin</h3><p>Demo idarəetmə paneli</p></div><div class="card" onclick="localStorage.removeItem('autolife');location.reload()"><div class="tile-icon">↻</div><h3>Sıfırla</h3><p class="danger">Demo məlumatlarını sil</p></div></div>`}
function admin(){return `<div class="section-title"><h2>Admin Panel</h2><span class="pill">Demo</span></div><div class="grid"><div class="card"><div class="tile-icon">👥</div><h3>İstifadəçilər</h3><p>1,248</p></div><div class="card"><div class="tile-icon">🚗</div><h3>Avtomobillər</h3><p>1,936</p></div><div class="card"><div class="tile-icon">🔧</div><h3>Servislər</h3><p>87</p></div><div class="card"><div class="tile-icon">🛒</div><h3>Sifarişlər</h3><p>326</p></div></div><div class="section-title"><h2>Backend status</h2></div><div class="row"><span class="success">● Online</span><div class="grow"><strong>AutoLife API</strong><small>/api/health</small></div></div>`}
window.addEventListener("hashchange",render);
render();