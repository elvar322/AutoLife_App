const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "AutoLife", version: "1.0.0" });
});

/*
  AI endpoint:
  - The frontend works without an AI key and returns a local demo answer.
  - To connect a real AI provider, set AI_API_URL and AI_API_KEY on Render
    and implement the provider request here.
*/
app.post("/api/ai", async (req, res) => {
  const message = String(req.body?.message || "").trim();

  if (!message) {
    return res.status(400).json({ error: "Mesaj boş ola bilməz." });
  }

  // Safe local fallback so the app is usable immediately.
  const lower = message.toLowerCase();
  let answer =
    "Mən AutoLife köməkçisiyəm. Avtomobilin markasını, modelini, ilini və problemin əlamətlərini yazsan, daha dəqiq istiqamət verə bilərəm.";

  if (lower.includes("yağ")) {
    answer = "Yağ dəyişmə intervalı mühərrikə və istehsalçı tövsiyəsinə görə dəyişir. Avtomobilinin marka, model, il və mühərrikini yaz.";
  } else if (lower.includes("əyləc") || lower.includes("fren")) {
    answer = "Əyləcdə səs, titrəmə və ya pedalın yumşalması varsa, təhlükəsizlik baxımından avtomobili yoxlatdırmaq yaxşıdır.";
  } else if (lower.includes("akkumulyator") || lower.includes("batareya")) {
    answer = "Akkumulyator problemi üçün ilk yoxlanacaq şeylər gərginlik, terminallar və soyuq start davranışıdır.";
  }

  res.json({ answer, demo: true });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`AutoLife running on port ${PORT}`);
});